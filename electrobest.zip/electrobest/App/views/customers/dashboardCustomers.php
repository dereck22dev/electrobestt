
<?php
session_start();
	$cid = $_SESSION['NavCid'];
	echo $cid;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Customer|Dashboard</title>
	<link rel="stylesheet" href="../ressources/css/style.css">
    <link rel="stylesheet" href="../ressources/css/normalize.css">
	<style>
    /* .shopname_zone div.slog{
        color:white;
    } */
    </style>
</head>
<body>

	<div class="customer_dashborad">
		<div class="customer_dashboard_header">
			<div class="customer_dashboard_header_top">
				<?php
					require "../App/views/shop-name.php";
				?>
			</div>

			<div class="complete_option_dashboard_customers">
				<nav>
					<ul>
						<li></li>
					</ul>
				</nav>
			</div>
		</div>

		<?php
			require "../App/views/products.php"; 
		?>

		<?php
			require "../App/views/footer.php"; 
		?>
	</div>

            <!-- End Header -->
	

</body>
</html>


