
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../ressources/css/style.css">
    <link rel="stylesheet" href="../ressources/css/normalize.css">
</head>
<body>

        <!-- header-top-navigation -->
            <?php
                require "../App/views/header-nav-bar.php";   
            ?>
        <!-- end header-top-navigation -->
        
        <!-- header-hero-zone -->
        <div class="hero-zone">
            <div class="hero-header-content">
                <h1><span class="hero-header-content-block1">Electronique</span> <span class="hero-header-content-block2">sans secret</span></h1>
                <p>ElectroBest vous accompagne dans la conception et la réalisation de vos projets électronique</p>
                <div class="link_header_hero">
                 <a href="products">Visiter nos produits high-Tech</a>
                </div>
            </div>
            <div class="hero-header-picture">
                <img src="../media/images/arduino.jpg" alt="">
            </div>
        </div>
        <!-- end header-hero-zone -->



        <main>
            <section class="website-speciality">
                <div class="content_before_specification_redirect">
                    <h2>Nos services</h2>
                    <p>Nous avons pour objectif de mettre a votre disposition, tous les 
                        composants dont vous pouvez avoir besoins pour vos projets. Bonne nouvelle, 
                        une équipe composé d'électroniciens et de programmeurs sont disponibles
                        pour toutes vos préoccupation. Pour les réponses rapide, consultez notre page FAQ. 
                    </p>
                </div>
                
                <div class="speciality-card">
                    <div class="components-access">
                        <img src="../media/images/composants.jpg" alt="">
                        <h3>Pieces électronique</h3>
                        <p>L'éssentiel de vos besoins en matiere de pieces électronique</p>
                    </div>

                    <div class="equipe-access">
                        <img src="../media/images/membership.jpg" alt="">
                        <h3>Membre ElectroBest</h3>
                        <p>Une équipe dynamique et attentive a l'écoute des clients</p>
                    </div>

                </div>
            </section>      
            <section>
                <h2 class="title_performancy">Performances</h3>
                <article>
                    <div class="wrapper">
                        <div class="container_counter_up">
                        <i class="svg_counter_bloc">
                        <svg width="60"xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25zm.75-12h9v9h-9v-9z" />
                            </svg>

                        </i>
                        <span class="num" data-val="350">000</span>
                        <span class="text">Projets réussis</span>
                        </div>
                        <div class="container_counter_up">
                        <i class="svg_counter_bloc">
                        <svg  width="60" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
                            </svg>

                        </i>
                        <span class="num" data-val="250">000</span>
                        <span class="text">clients satisfaits</span>
                        </div>
                        <div class="container_counter_up">
                        <i  class="svg_counter_bloc">
                        <svg width="60" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398C3.387 10.203 4.167 9.75 5 9.75h1.053c.472 0 .745.556.5.96a8.958 8.958 0 00-1.302 4.665c0 1.194.232 2.333.654 3.375z" />
                            </svg>

                        </i>
                        <span class="num" data-val="325">000</span>
                        <span class="text">Followers</span>
                        </div>
                        <div class="container_counter_up">
                        <i class="svg_counter_bloc">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                        </svg>
                        </i>
                        <span class="num" data-val="275">000</span>
                        <span class="text">produits</span>
                        </div>
                    </div>
                </article>
            </section>
            
        </main>

        <?php
            require "../App/views/footer.php"
        ?>

        <script src="../ressources/js/count_up_homepage.js"></script>
</body>
</html>