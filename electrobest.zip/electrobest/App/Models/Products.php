<?php 

    namespace App\Models;

    use App\Models\Connexions;

    class UserModel extends Connexions{
      
            /**
     * $conn
     */

    public $conn;
    public $username;
    public $email;
    public $password;
    public $phoneNumber;
    public $emailConnexion;
    public $emailConnect;

    /**
     * verify()
     */
    public function verifyEmail($email) {
      /**
     * verify()
     */
   
        $this->email = $email;

        /**
         * 
         */
        $conn = $this->connect();
        /**
         * $sql
         */
        $sql = "SELECT * FROM `electrobest`.customer WHERE useremail = ?;";
        /**
         * $stmt
         */
        $stmt = $conn->prepare($sql);
        $stmt->execute([$this->email]);
        $result = $stmt->fetchAll();
        return $result;
    }

}
        
   