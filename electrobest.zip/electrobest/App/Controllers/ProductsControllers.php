<?php

namespace App\Controllers;

use App\Models\UserModel;



class ProductsControllers  {
/**
 * $usermodel
 */
public $product_category;
public $product_name;
public $description_product;
public $product_price;
public $product_file;
public $productsModel;

public function __construct($product_category, 
$product_name, $description_product,  
$$product_price, $product_file) {
    $this->product_category = $product_category;
    $this->product_name = $product_name;
    $this->description_product = $description_product;
    $this->product_price = $product_price;
    $this->$product_file=$product_file;
    $this->usermodel = new productsModel();
}

public function recupDataProductSend(){
    if(!isset($_POST["submit"])){
        echo 'r';
    }
}

}