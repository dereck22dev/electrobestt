
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/ressources/css/style.css">
    
</head>
<body>
    
</body>
</html>
<!-- shopname-zone -->
<div class="shopname_zone">
                <div class="shopname">
                    <span class="shopname_block1">Electro</span ><span class="shopname_block2">Best</span>
                </div>
                <div class="slog">
                    <span>MAGIC COMPONENTS</span>
                </div>     
</div>
            <!-- end shopname zone -->
